import os
import subprocess

from clases.utils import python_version


def prepareCycleGAN():
    clases_dir = os.path.dirname(__file__)
    src_dir = os.path.join(clases_dir, "../")
    cycleGan_dir = os.path.join(src_dir, "../tmp/pytorch-CycleGAN-and-pix2pix")

    if not os.path.exists(cycleGan_dir):
        subprocess.run(['git', 'clone', 'https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix', cycleGan_dir])
        requirements_dir = os.path.join(cycleGan_dir, 'requirements.txt')
        subprocess.run(['pip', 'install', '-r', requirements_dir])
    os.chdir(cycleGan_dir)
    POLYP_DATASET_DIR = os.path.join(src_dir, "../data/PolypDataset")
    python_installed = python_version()
    print(POLYP_DATASET_DIR)
    print(python_installed)
    return POLYP_DATASET_DIR, python_installed, cycleGan_dir
