import argparse
import csv
import os
import sys

import optuna
import torch
from torch.utils.data import Subset


def fix_path():
    # Add clases folder to path
    script_dir = os.path.dirname(__file__)
    relative_path = "clases"
    absolute_path = os.path.join(script_dir, relative_path)
    print(absolute_path)
    sys.path.append(absolute_path)


fix_path()
from clases.model_utils import train_model, prepare_dataset


def objective(trial, metric_to_optimize='f1', model_name='FasterRCNN', debug=False):
    lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
    batch_size = trial.suggest_categorical("batch_size", [2, 4, 8])  # TODO: BATCH SIZE OF 16 BREAKS THINGS
    weight_decay = trial.suggest_float("weight_decay", 1e-5, 1e-1, log=True)
    num_epochs = trial.suggest_int("num_epochs", 1, 5)  # TODO: more epochs when we have more time

    params = {
        "BATCH_SIZE": batch_size,
        "LR": lr,
        "WEIGHT_DECAY": weight_decay,
        "NUM_EPOCHS": num_epochs
    }

    train_dataset, _ = prepare_dataset()
    if debug:
        n_samples = 20
        subset_indices = torch.randperm(len(train_dataset))[:n_samples]
        train_dataset = Subset(train_dataset, subset_indices)
    else:
        train_dataset = train_dataset

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # Validation split is done inside the train_model function already
    trained_model, _, _, _, _, metric_to_optimize = train_model(train_dataset, params, num_epochs, device, model_name,
                                                                debug=debug, metric_choice=metric_to_optimize)
    # Free memory
    if device.type == 'cuda':
        torch.cuda.empty_cache()

    return metric_to_optimize


parser = argparse.ArgumentParser(description='Run Optuna optimization.',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('model_name', type=str, help='Name of the model to train.')
parser.add_argument('--metric', type=str, default='f1', choices=['f1', 'mean_iou'], help='Metric to optimize.')
parser.add_argument('--debug', action='store_true', help='Run in debug mode with a smaller subset of data.')

args = parser.parse_args()

study = optuna.create_study(direction='maximize')
study.optimize(
    lambda trial: objective(trial, metric_to_optimize=args.metric, model_name=args.model_name, debug=args.debug),
    n_trials=5)  # TODO: more trials when we have more time

best_params = study.best_params
print("Best hyperparameters: ", best_params)

with open('best_hyperparameters.csv', 'w', newline='') as csvfile:
    fieldnames = ['parameter', 'value']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for param, value in best_params.items():
        writer.writerow({'parameter': param, 'value': value})

# On a search with 5 trials, I got:
# Best hyperparameters:  {'lr': 0.030835981129087326, 'batch_size': 2, 'weight_decay': 0.0001317937713104395, 'num_epochs': 2}
